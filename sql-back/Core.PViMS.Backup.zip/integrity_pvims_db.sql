EXECUTE dbo.DatabaseIntegrityCheck 
		@Databases = 'PViMS.Demo', 
		@CheckCommands = 'CHECKDB'
